const socket = io();

const qs = (s)=>document.querySelector(s);
const qsa=(s)=>document.querySelectorAll(s);

const authSec = qs('#auth');
const lobbySec = qs('#lobby');
const secretSec = qs('#secret');
const revealSec = qs('#reveal');

const nameInput = qs('#nameInput');
const codeInput = qs('#codeInput');
const createBtn = qs('#createBtn');
const joinBtn = qs('#joinBtn');
const startBtn = qs('#startBtn');
const revealBtn = qs('#revealBtn');
const newRoundBtn = qs('#newRoundBtn');
const playersDiv = qs('#players');
const roomCodeEl = qs('#roomCode');
const hostHint = qs('#hostHint');
const secretWordEl = qs('#secretWord');
const roleTag = qs('#roleTag');
const poolInput = qs('#poolInput');
const revealList = qs('#revealList');

let isHost = false;
let mySecret = null;

const show = (el)=>el.classList.remove('hidden');
const hide = (el)=>el.classList.add('hidden');

createBtn.onclick = () => {
  const name = nameInput.value.trim() || 'Jugador';
  socket.emit('createRoom', { name });
};

joinBtn.onclick = () => {
  const code = (codeInput.value || '').trim().toUpperCase();
  const name = nameInput.value.trim() || 'Jugador';
  if (code.length !== 4) return alert('Código inválido (4 caracteres).');
  socket.emit('joinRoom', { code, name });
};

startBtn.onclick = () => {
  if (!isHost) return alert('Solo el host puede iniciar.');
  const raw = (poolInput.value || '')
    .split('\\n')
    .map(s => s.trim())
    .filter(Boolean);
  socket.emit('startGame', { customPool: raw });
};

revealBtn.onclick = () => {
  if (!isHost) return alert('Solo el host puede revelar.');
  socket.emit('reveal');
};

newRoundBtn.onclick = () => {
  if (!isHost) return alert('Solo el host puede reiniciar ronda.');
  socket.emit('newRound');
};

nameInput.addEventListener('change', ()=>{
  socket.emit('setName', { name: nameInput.value.trim() });
});

socket.on('errorMsg', (msg) => alert(msg));

socket.on('roomCreated', ({ code, players }) => {
  isHost = true;
  roomCodeEl.textContent = code;
  renderPlayers(players);
  hide(authSec); show(lobbySec);
  hostHint.textContent = 'Sos el host. Esperá jugadores y apretá “Iniciar”.';
});

socket.on('joined', ({ code, players, isHost: meHost }) => {
  isHost = meHost;
  roomCodeEl.textContent = code;
  renderPlayers(players);
  hide(authSec); show(lobbySec);
  hostHint.textContent = isHost ? 'Sos el host. Esperá jugadores y apretá “Iniciar”.' : 'Esperando a que el host inicie la ronda…';
});

socket.on('playersUpdate', (players) => {
  renderPlayers(players);
});

socket.on('gameStarted', () => {
  hide(revealSec);
});

socket.on('yourSecret', ({ secret, isImpostor }) => {
  mySecret = secret;
  secretWordEl.textContent = secret;
  roleTag.textContent = isImpostor ? 'IMPOSTOR' : 'Jugador';
  roleTag.classList.toggle('imp', !!isImpostor);
  show(secretSec);
});

socket.on('revealed', (list) => {
  revealList.innerHTML = '';
  list.forEach(p => {
    const row = document.createElement('div');
    row.className = 'row';
    const left = document.createElement('div');
    left.textContent = p.name;
    const right = document.createElement('div');
    right.innerHTML = `<span class="tag ${p.isImpostor?'imp':''}">${p.isImpostor?'IMPOSTOR':'Jugador'}</span> — <b>${p.secret}</b>`;
    row.append(left, right);
    revealList.append(row);
  });
  show(revealSec);
});

socket.on('roundReset', () => {
  mySecret = null;
  secretWordEl.textContent = '—';
  roleTag.textContent = 'Jugador';
  roleTag.classList.remove('imp');
  hide(revealSec);
});

// UI helpers
function renderPlayers(players){
  playersDiv.innerHTML = '';
  players.forEach(p => {
    const pill = document.createElement('div');
    pill.className = 'pill';
    const name = document.createElement('div');
    name.textContent = p.name;
    const tag = document.createElement('span');
    tag.className = 'tag' + (p.isHost ? ' host' : '');
    tag.textContent = p.isHost ? 'Host' : 'Listo';
    pill.append(name, tag);
    playersDiv.append(pill);
  });
}
