import express from 'express';
import http from 'http';
import { Server } from 'socket.io';

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

const PORT = process.env.PORT || 3000;

/** Estado en memoria: rooms[code] = {
 *   hostId, players: { [socketId]: {name, isHost, secret, isImpostor} },
 * } */
const rooms = Object.create(null);

// Lista base de futbolistas (puedes editar/liberar/añadir)
const DEFAULT_POOL = [
  "Lionel Messi","Cristiano Ronaldo","Neymar","Kylian Mbappé","Erling Haaland",
  "Luka Modrić","Kevin De Bruyne","Mohamed Salah","Robert Lewandowski","Harry Kane",
  "Antoine Griezmann","Jude Bellingham","Vinícius Júnior","Paulo Dybala","Ángel Di María",
  "Karim Benzema","Sergio Agüero","Thiago Silva","Toni Kroos","Marcelo",
  "Zlatan Ibrahimović","Andrés Iniesta","Xavi Hernández","Sergio Busquets","Luis Suárez",
  "Gianluigi Buffon","Iker Casillas","Virgil van Dijk","Ronaldinho","Kaká",
  "Didier Drogba","Samuel Eto'o","Riyad Mahrez","Bernardo Silva","Phil Foden",
  "Rodri","Lautaro Martínez","Enzo Fernández","Julián Álvarez","Federico Valverde"
];

// Helpers
const genCode = () => {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 4; i++) s += alphabet[Math.floor(Math.random()*alphabet.length)];
  return s;
};

const getRoom = (code) => rooms[code];
const listPlayers = (code) =>
  Object.entries(rooms[code]?.players || {}).map(([id, p]) => ({ id, name: p.name, isHost: p.isHost }));

const sanitizeName = (str) => String(str || '').trim().slice(0, 32) || 'Jugador';

io.on('connection', (socket) => {
  let currentRoom = null;

  socket.on('createRoom', ({ name }) => {
    let code;
    do { code = genCode(); } while (rooms[code]);
    rooms[code] = { hostId: socket.id, players: {} };
    currentRoom = code;
    rooms[code].players[socket.id] = { name: sanitizeName(name), isHost: true, secret: null, isImpostor: false };
    socket.join(code);
    io.to(socket.id).emit('roomCreated', { code, players: listPlayers(code), isHost: true });
  });

  socket.on('joinRoom', ({ code, name }) => {
    code = String(code || '').toUpperCase();
    const room = getRoom(code);
    if (!room) return io.to(socket.id).emit('errorMsg', 'Sala no encontrada.');
    if (Object.keys(room.players).length >= 20) return io.to(socket.id).emit('errorMsg', 'Sala llena (máx. 20).');

    currentRoom = code;
    room.players[socket.id] = { name: sanitizeName(name), isHost: false, secret: null, isImpostor: false };
    socket.join(code);

    io.to(socket.id).emit('joined', { code, players: listPlayers(code), isHost: false });
    io.to(code).emit('playersUpdate', listPlayers(code));
  });

  socket.on('setName', ({ name }) => {
    const room = getRoom(currentRoom);
    if (!room || !room.players[socket.id]) return;
    room.players[socket.id].name = sanitizeName(name);
    io.to(currentRoom).emit('playersUpdate', listPlayers(currentRoom));
  });

  socket.on('startGame', ({ customPool }) => {
    const room = getRoom(currentRoom);
    if (!room) return;
    if (room.hostId !== socket.id) return io.to(socket.id).emit('errorMsg', 'Solo el host puede iniciar.');

    const playersIds = Object.keys(room.players);
    if (playersIds.length < 3) return io.to(socket.id).emit('errorMsg', 'Mínimo 3 jugadores.');

    // Armar pool
    let pool = Array.isArray(customPool) && customPool.length >= playersIds.length - 1
      ? customPool.slice()
      : DEFAULT_POOL.slice();

    // Barajar
    pool = pool.sort(() => Math.random() - 0.5);

    // Elegir impostor
    const impostorIndex = Math.floor(Math.random() * playersIds.length);
    playersIds.forEach((pid, idx) => {
      const isImp = idx === impostorIndex;
      const secret = isImp ? 'IMPOSTOR' : pool[idx >= impostorIndex ? idx - 1 : idx]; // correr para saltar al impostor
      const p = room.players[pid];
      p.isImpostor = isImp;
      p.secret = secret;
      io.to(pid).emit('yourSecret', { secret, isImpostor: isImp });
    });

    io.to(currentRoom).emit('gameStarted', listPlayers(currentRoom));
  });

  socket.on('reveal', () => {
    const room = getRoom(currentRoom);
    if (!room) return;
    if (room.hostId !== socket.id) return io.to(socket.id).emit('errorMsg', 'Solo el host puede revelar.');

    const payload = Object.entries(room.players).map(([id, p]) => ({
      id, name: p.name, isImpostor: p.isImpostor, secret: p.secret
    }));
    io.to(currentRoom).emit('revealed', payload);
  });

  socket.on('newRound', () => {
    const room = getRoom(currentRoom);
    if (!room) return;
    if (room.hostId !== socket.id) return io.to(socket.id).emit('errorMsg', 'Solo el host puede reiniciar ronda.');

    // limpiar secretos para siguiente ronda
    Object.values(room.players).forEach(p => { p.secret = null; p.isImpostor = false; });
    io.to(currentRoom).emit('roundReset');
  });

  socket.on('disconnect', () => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    if (!room) return;

    delete room.players[socket.id];

    // Si era host y quedan jugadores, pasar host al primero
    if (room.hostId === socket.id) {
      const ids = Object.keys(room.players);
      if (ids.length) {
        room.hostId = ids[0];
        room.players[room.hostId].isHost = true;
      } else {
        // sala vacía -> eliminar
        delete rooms[currentRoom];
      }
    }

    io.to(currentRoom).emit('playersUpdate', listPlayers(currentRoom));
  });
});

server.listen(PORT, () => {
  console.log(`El Impostor escuchando en http://localhost:${PORT}`);
});
